package com.lti.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.lti.model.Employee;
import com.lti.service.EmployeeService;

@RestController
@RequestMapping(path = "employee")
@CrossOrigin
public class EmployeeRestController {

	@Autowired
	private EmployeeService service;

	@RequestMapping(method = RequestMethod.GET)
	public List<Employee> viewAllEmployees() {
		List<Employee> list = service.findAllEmployees();
		return list;
	}

	@RequestMapping(path = "{EMPLOYEE_ID}", method = RequestMethod.GET)
	public Employee viewEmployeeById(@PathVariable("EMPLOYEE_ID") int employeeId) {
		return service.findEmployeeById(employeeId);

	}

	@RequestMapping(path = "{EMPLOYEE_ID}", method = RequestMethod.DELETE)
	public List<Employee> deleteEmployee(@PathVariable("EMPLOYEE_ID") int employeeId) {
		boolean result = service.removeEmployee(employeeId);
		return service.findAllEmployees();
	}

	@RequestMapping(method = RequestMethod.POST)
	public List<Employee> addEmployee(@RequestBody Employee employee) {
		boolean result = service.addEmployee(employee);
		return service.findAllEmployees();
	}

	@RequestMapping(method = RequestMethod.PUT)
	public List<Employee> updateEmployee(@RequestBody Employee employee) {
		Employee result = service.modifyEmployee(employee);
		return service.findAllEmployees();

	}

}
